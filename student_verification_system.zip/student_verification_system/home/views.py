from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import Group
from .forms import UserRegistrationForm
from django.shortcuts import render
from .decorators import role_required
from .forms import DocumentForm
from .models import Document
from django.core.mail import send_mail
from django.contrib.auth.decorators import login_required

def home(request):
    return render(request, 'core/home.html')

def register(request):
    # registration logic here
    return render(request, 'registration/register.html')

def login(request):
    # login logic here
    return render(request, 'registration/login.html')

def guest_upload(request):
    return render(request, 'registration/guest_upload.html')

def admin_upload(request):
    return render(request, 'registration/admin_upload.html')

def user_upload(request):
    return render(request, 'registration/user_upload.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            new_user = form.save(commit=False)
            new_user.set_password(form.cleaned_data['password'])
            new_user.save()
            # Assign the user to the 'guest' group by default
            guest_group = Group.objects.get(name='guest')
            guest_group.user_set.add(new_user)
            user = authenticate(username=new_user.username, password=form.cleaned_data['password'])
            login(request, user)
            return redirect('home')
    else:
        form = UserRegistrationForm()
    return render(request, 'core/register.html', {'form': form})

@login_required
def verification_result(request):
    # Implement your logic here
    return render(request, 'core/verification_result.html')

@role_required('admin')
def admin_upload(request):
    if request.method == 'POST':
        form = AdminUploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('upload_success')
    else:
        form = AdminUploadForm()
    return render(request, 'admin_upload.html', {'form': form})

@role_required('guest')
@role_required('normal')
def user_upload(request):
    if request.method == 'POST':
        form = UserUploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('upload_success')
    else:
        form = UserUploadForm()
    return render(request, 'user_upload.html', {'form': form})

# @role_required('guest')
def guest_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            document = form.save(commit=False)
            document.user = request.user
            document.save()
            return redirect('upload_success')
    else:
        form = DocumentForm()
    return render(request, 'guest_upload.html', {'form': form})

@role_required('normal')
def user_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            document = form.save(commit=False)
            document.user = request.user
            document.save()
            return redirect('upload_success')
    else:
        form = DocumentForm()
    return render(request, 'user_upload.html', {'form': form})

@role_required('admin')
def admin_upload(request):
    if request.method == 'POST':
        form = RecordForm(request.POST, request.FILES)
        if form.is_valid():
            # Handle file upload and save records to remote database
            handle_uploaded_file(request.FILES['record_file'])
            return redirect('upload_success')
    else:
        form = RecordForm()
    return render(request, 'admin_upload.html', {'form': form})

def handle_uploaded_file(f):
    # Logic to handle file and save records to remote database
    pass

@role_required('guest')
def verify_document_view(request, document_id):
    document = get_object_or_404(Document, id=document_id)
    result = verify_document(document)
    status = 'valid' if result == 1 else 'invalid'
    return render(request, 'verification_result.html', {'status': status})

def send_verification_email(user, status):
    subject = 'Document Verification Status'
    message = f'Your document has been verified and the status is: {status}.'
    send_mail(subject, message, 'from@example.com', [user.email])

@role_required('guest')
def verify_document_view(request, document_id):
    document = get_object_or_404(Document, id=document_id)
    result = verify_document(document)
    status = 'valid' if result == 1 else 'invalid'
    send_verification_email(request.user, status)
    return render(request, 'verification_result.html', {'status': status})

