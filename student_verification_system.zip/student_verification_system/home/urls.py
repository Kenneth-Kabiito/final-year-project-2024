# core/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('admin_upload/', views.admin_upload, name='admin_upload'),
    path('user_upload/', views.user_upload, name='user_upload'),
    path('guest_upload/', views.guest_upload, name='guest_upload'),
    path('verification_result/', views.verification_result, name='verification_result'),
    # Add other paths here
]
